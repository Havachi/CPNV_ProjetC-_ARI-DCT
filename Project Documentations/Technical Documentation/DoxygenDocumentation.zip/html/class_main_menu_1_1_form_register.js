var class_main_menu_1_1_form_register =
[
    [ "FormRegister", "class_main_menu_1_1_form_register.html#a99ed04abb3edc65398b5b02c144cc5d2", null ],
    [ "Dispose", "class_main_menu_1_1_form_register.html#af93e45e5c7181f90d10d5fa111c3e8ce", null ],
    [ "FormMainMenu", "class_main_menu_1_1_form_register.html#ab7314548e448f2791fa15c20a8891dd9", null ],
    [ "formRegister", "class_main_menu_1_1_form_register.html#a72c30f512c642367a0ef2be24dd2e49f", null ]
];