var class_d_b_connection_lib_1_1_unknown_user_email_address_exception =
[
    [ "UnknownUserEmailAddressException", "class_d_b_connection_lib_1_1_unknown_user_email_address_exception.html#affddfa0f4c980a2548eb8d72ec76af4d", null ],
    [ "UnknownUserEmailAddressException", "class_d_b_connection_lib_1_1_unknown_user_email_address_exception.html#a9d86c2957cdcb5cd5cec8883cf28508b", null ]
];