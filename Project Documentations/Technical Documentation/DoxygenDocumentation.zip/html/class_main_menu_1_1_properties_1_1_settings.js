var class_main_menu_1_1_properties_1_1_settings =
[
    [ "FormMainLoc", "class_main_menu_1_1_properties_1_1_settings.html#a13aa13a3cbf6d4e7cdf5ba949d77a70d", null ],
    [ "FormMainSize", "class_main_menu_1_1_properties_1_1_settings.html#aeac2f254e369b271c90ca4170951d4cd", null ],
    [ "FormMainState", "class_main_menu_1_1_properties_1_1_settings.html#a69b607273c95fffb17bcedd0ace6f999", null ]
];