var namespace_main_menu =
[
    [ "Properties", "namespace_main_menu_1_1_properties.html", "namespace_main_menu_1_1_properties" ],
    [ "ArgumentNullException", "class_main_menu_1_1_argument_null_exception.html", "class_main_menu_1_1_argument_null_exception" ],
    [ "FormLogin", "class_main_menu_1_1_form_login.html", "class_main_menu_1_1_form_login" ],
    [ "FormMainMenu", "class_main_menu_1_1_form_main_menu.html", "class_main_menu_1_1_form_main_menu" ],
    [ "FormRegister", "class_main_menu_1_1_form_register.html", "class_main_menu_1_1_form_register" ]
];