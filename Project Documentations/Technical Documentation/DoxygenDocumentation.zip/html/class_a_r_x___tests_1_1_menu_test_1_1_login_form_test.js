var class_a_r_x___tests_1_1_menu_test_1_1_login_form_test =
[
    [ "TestLoginFormBothEmpty", "class_a_r_x___tests_1_1_menu_test_1_1_login_form_test.html#a51e04d2b9e984eda7f444dce0490be2b", null ],
    [ "TestLoginFormMailEmpty", "class_a_r_x___tests_1_1_menu_test_1_1_login_form_test.html#ad8b31fba3e4f47afb95887e36b6afcc9", null ],
    [ "TestLoginFormPasswordEmpty", "class_a_r_x___tests_1_1_menu_test_1_1_login_form_test.html#a785ec71db8bdeae77123192674bc5fbb", null ],
    [ "TestLoginFormPasswordTooshort", "class_a_r_x___tests_1_1_menu_test_1_1_login_form_test.html#abbefd9ab937a30a1317d42607c90bab4", null ],
    [ "TestRegisterFormGenerateUsername", "class_a_r_x___tests_1_1_menu_test_1_1_login_form_test.html#a63039d81ca83545b3644bf493aadc2f5", null ]
];