var class_a_r_x___tests_1_1_player_test =
[
    [ "CreateNewPlayerTest", "class_a_r_x___tests_1_1_player_test.html#a126fcf32304cbf32ce0c78a13ebb19d3", null ],
    [ "MovePlayerTest", "class_a_r_x___tests_1_1_player_test.html#a9c1ca2490501fa88ed6f362fff9e256a", null ],
    [ "TeleportPlayerTest", "class_a_r_x___tests_1_1_player_test.html#a508f5a5c4f1543f4e4cdfadaf7146255", null ],
    [ "TurnPlayerTest", "class_a_r_x___tests_1_1_player_test.html#a8c954189fd4591611ba4dcc454c7e9fb", null ]
];