var dir_7bf205e325f58c5585a2ed0be65c452c =
[
    [ "AssemblyInfo.cs", "_map_lib_2_properties_2_assembly_info_8cs_source.html", null ]
];