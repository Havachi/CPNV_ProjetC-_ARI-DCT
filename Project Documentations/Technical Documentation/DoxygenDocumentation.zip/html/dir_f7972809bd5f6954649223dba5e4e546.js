var dir_f7972809bd5f6954649223dba5e4e546 =
[
    [ "AssemblyInfo.cs", "_main_menu_2_properties_2_assembly_info_8cs_source.html", null ],
    [ "Resources.Designer.cs", "_main_menu_2_properties_2_resources_8_designer_8cs_source.html", null ],
    [ "Settings.Designer.cs", "_main_menu_2_properties_2_settings_8_designer_8cs_source.html", null ]
];