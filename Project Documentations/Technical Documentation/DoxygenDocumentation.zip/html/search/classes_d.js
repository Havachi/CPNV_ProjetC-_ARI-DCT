var searchData=
[
  ['unknownuseremailaddressexception',['UnknownUserEmailAddressException',['../class_d_b_connection_lib_1_1_unknown_user_email_address_exception.html',1,'DBConnectionLib']]],
  ['unknownusernameexception',['UnknownUsernameException',['../class_d_b_connection_lib_1_1_unknown_username_exception.html',1,'DBConnectionLib']]],
  ['useremailalreadyexistexception',['UserEmailAlreadyExistException',['../class_d_b_connection_lib_1_1_user_email_already_exist_exception.html',1,'DBConnectionLib']]],
  ['usernamealreadyexistexception',['UsernameAlreadyExistException',['../class_d_b_connection_lib_1_1_username_already_exist_exception.html',1,'DBConnectionLib']]]
];
