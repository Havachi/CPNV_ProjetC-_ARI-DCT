var searchData=
[
  ['dbconnection',['DbConnection',['../class_d_b_connection_lib_1_1_db_connection.html#ab620a30b00010cd42657b9aabcc8e618',1,'DBConnectionLib::DbConnection']]],
  ['dispose',['Dispose',['../class_game_1_1frm_game.html#a1efe660691adff74f3db58387a02495c',1,'Game.frmGame.Dispose()'],['../class_main_menu_1_1_form_login.html#a2c7bec26f7607f6803d1d2f0af5359d9',1,'MainMenu.FormLogin.Dispose()'],['../class_main_menu_1_1_form_main_menu.html#adf3994ab55f6d58d7eba506a2f60d6e8',1,'MainMenu.FormMainMenu.Dispose()'],['../class_main_menu_1_1_form_register.html#af93e45e5c7181f90d10d5fa111c3e8ce',1,'MainMenu.FormRegister.Dispose()']]]
];
