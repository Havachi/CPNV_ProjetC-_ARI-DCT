var searchData=
[
  ['register',['Register',['../class_main_menu_lib_1_1_register.html',1,'MainMenuLib.Register'],['../class_main_menu_lib_1_1_register.html#ae8df5bee13296eed56564238375c3f89',1,'MainMenuLib.Register.Register()']]],
  ['registerindb',['RegisterInDb',['../class_main_menu_lib_1_1_register.html#a5646dd076766b5c2a7a788893bbc54ea',1,'MainMenuLib::Register']]],
  ['registertest',['RegisterTest',['../class_a_r_x___tests_1_1_register_test.html',1,'ARX_Tests']]],
  ['resources',['Resources',['../class_game_1_1_properties_1_1_resources.html',1,'Game.Properties.Resources'],['../class_main_menu_1_1_properties_1_1_resources.html',1,'MainMenu.Properties.Resources']]]
];
