var searchData=
[
  ['settings',['Settings',['../class_game_1_1_properties_1_1_settings.html',1,'Game.Properties.Settings'],['../class_main_menu_1_1_properties_1_1_settings.html',1,'MainMenu.Properties.Settings']]]
];
