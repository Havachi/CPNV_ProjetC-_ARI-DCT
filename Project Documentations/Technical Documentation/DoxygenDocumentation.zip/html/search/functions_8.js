var searchData=
[
  ['register',['Register',['../class_main_menu_lib_1_1_register.html#ae8df5bee13296eed56564238375c3f89',1,'MainMenuLib::Register']]],
  ['registerindb',['RegisterInDb',['../class_main_menu_lib_1_1_register.html#a5646dd076766b5c2a7a788893bbc54ea',1,'MainMenuLib::Register']]]
];
