var searchData=
[
  ['username',['Username',['../class_game_lib_1_1_player.html#a85612a9fbc0c55f99e9145f99f3472a2',1,'GameLib::Player']]]
];
