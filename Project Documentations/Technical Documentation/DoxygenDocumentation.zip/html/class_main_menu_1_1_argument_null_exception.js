var class_main_menu_1_1_argument_null_exception =
[
    [ "ArgumentNullException", "class_main_menu_1_1_argument_null_exception.html#a199005c23cbb7755491820a137abf5b7", null ],
    [ "ArgumentNullException", "class_main_menu_1_1_argument_null_exception.html#a828abac991c4d8f0ca2fc74a855dac4c", null ]
];