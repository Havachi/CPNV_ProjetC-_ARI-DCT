var namespace_a_r_x___tests =
[
    [ "DbConnectionTest", "class_a_r_x___tests_1_1_db_connection_test.html", "class_a_r_x___tests_1_1_db_connection_test" ],
    [ "GameTest", "class_a_r_x___tests_1_1_game_test.html", null ],
    [ "GenerationTest", "class_a_r_x___tests_1_1_generation_test.html", "class_a_r_x___tests_1_1_generation_test" ],
    [ "LoginTest", "class_a_r_x___tests_1_1_login_test.html", "class_a_r_x___tests_1_1_login_test" ],
    [ "MapTest", "class_a_r_x___tests_1_1_map_test.html", "class_a_r_x___tests_1_1_map_test" ],
    [ "MenuTest", "class_a_r_x___tests_1_1_menu_test.html", [
      [ "LoginFormTest", "class_a_r_x___tests_1_1_menu_test_1_1_login_form_test.html", "class_a_r_x___tests_1_1_menu_test_1_1_login_form_test" ]
    ] ],
    [ "PlayerTest", "class_a_r_x___tests_1_1_player_test.html", "class_a_r_x___tests_1_1_player_test" ],
    [ "RegisterTest", "class_a_r_x___tests_1_1_register_test.html", "class_a_r_x___tests_1_1_register_test" ]
];