var class_d_b_connection_lib_1_1_user_email_already_exist_exception =
[
    [ "UserEmailAlreadyExistException", "class_d_b_connection_lib_1_1_user_email_already_exist_exception.html#a093f195b2f60a6e6ba49b84ee3cd2220", null ],
    [ "UserEmailAlreadyExistException", "class_d_b_connection_lib_1_1_user_email_already_exist_exception.html#a3d239d3515347a272d41c2732aa386df", null ]
];