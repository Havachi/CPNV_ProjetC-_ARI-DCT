var dir_df05720a0f73e5a810d0c0e141978fb3 =
[
    [ "AssemblyInfo.cs", "_game_2_properties_2_assembly_info_8cs_source.html", null ],
    [ "Resources.Designer.cs", "_game_2_properties_2_resources_8_designer_8cs_source.html", null ],
    [ "Settings.Designer.cs", "_game_2_properties_2_settings_8_designer_8cs_source.html", null ]
];