var namespace_main_menu_1_1_properties =
[
    [ "Resources", "class_main_menu_1_1_properties_1_1_resources.html", null ],
    [ "Settings", "class_main_menu_1_1_properties_1_1_settings.html", "class_main_menu_1_1_properties_1_1_settings" ]
];