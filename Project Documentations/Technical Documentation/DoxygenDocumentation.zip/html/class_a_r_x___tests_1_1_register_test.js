var class_a_r_x___tests_1_1_register_test =
[
    [ "TestRegisterInDbWithValidInput", "class_a_r_x___tests_1_1_register_test.html#a84f7057cd5e3c6a517948f7c11f39432", null ],
    [ "TestRegisterWithTooShortEmailAddress", "class_a_r_x___tests_1_1_register_test.html#a78cd51fa801de75aa17ef761f3916f4a", null ],
    [ "TestRegisterWithTooShortPassword", "class_a_r_x___tests_1_1_register_test.html#a9711108740fc6b8bf795d71e745c00fc", null ]
];