var namespace_game =
[
    [ "Properties", "namespace_game_1_1_properties.html", "namespace_game_1_1_properties" ],
    [ "frmGame", "class_game_1_1frm_game.html", "class_game_1_1frm_game" ]
];