var class_main_menu_1_1_form_main_menu =
[
    [ "FormMainMenu", "class_main_menu_1_1_form_main_menu.html#a108309fbbdddffb486de5ef8001b3350", null ],
    [ "Dispose", "class_main_menu_1_1_form_main_menu.html#adf3994ab55f6d58d7eba506a2f60d6e8", null ]
];