var class_a_r_x___tests_1_1_login_test =
[
    [ "Initialize", "class_a_r_x___tests_1_1_login_test.html#a532af1b63c544de31b7cbd44321ad768", null ],
    [ "TestLoginEmptyField", "class_a_r_x___tests_1_1_login_test.html#a519d6a87b7da93366efb2c035e83a035", null ],
    [ "TestLoginExistingUser", "class_a_r_x___tests_1_1_login_test.html#aa0a753db68dd9b9e7a30a2724565cd03", null ],
    [ "TestLoginWithWrongPassword", "class_a_r_x___tests_1_1_login_test.html#adb8c84abd7acd12b45a09878930eff0a", null ]
];