var class_d_b_connection_lib_1_1_username_already_exist_exception =
[
    [ "UsernameAlreadyExistException", "class_d_b_connection_lib_1_1_username_already_exist_exception.html#a3adb0b8d1614fc4bce513f73813652cf", null ],
    [ "UsernameAlreadyExistException", "class_d_b_connection_lib_1_1_username_already_exist_exception.html#af13c53f9d682e41281acf39731199055", null ]
];