var class_main_menu_lib_1_1_check_data =
[
    [ "CheckData", "class_main_menu_lib_1_1_check_data.html#a83d5599a41460d83c256b7e7a32bccae", null ],
    [ "CheckData", "class_main_menu_lib_1_1_check_data.html#a2797d65a9b1122849a1c3b7413959211", null ],
    [ "CheckLoginField", "class_main_menu_lib_1_1_check_data.html#a98efad5869d41599f67f0e0b74895f12", null ],
    [ "CheckRegisterField", "class_main_menu_lib_1_1_check_data.html#a303e5c050ec07ef70030b44c28e1583e", null ],
    [ "IsValidEmail", "class_main_menu_lib_1_1_check_data.html#aef1fe16ecfdd58505c17c2a4661fa0c6", null ],
    [ "VerifRegister", "class_main_menu_lib_1_1_check_data.html#af7b14c4c5afeea2391aa0b996988cfa5", null ]
];