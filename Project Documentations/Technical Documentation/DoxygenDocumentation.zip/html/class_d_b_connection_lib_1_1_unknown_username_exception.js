var class_d_b_connection_lib_1_1_unknown_username_exception =
[
    [ "UnknownUsernameException", "class_d_b_connection_lib_1_1_unknown_username_exception.html#a0e1497a1efbb23662564eb7a5d67f27f", null ],
    [ "UnknownUsernameException", "class_d_b_connection_lib_1_1_unknown_username_exception.html#a5762c18be09cc8c86c231469ee00ad13", null ]
];